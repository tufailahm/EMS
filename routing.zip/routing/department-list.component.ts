import { Component } from '@angular/core';

@Component({
  selector: 'department-app',
  template: `<h3>Department List </h3>
              `,
})
export class DepartmentListComponent 
{
}
