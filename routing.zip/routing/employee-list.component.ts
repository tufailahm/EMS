import { Component } from '@angular/core';

@Component({
  selector: 'employee-app',
  template: `<h3>Employee List </h3>
              `,
})
export class EmployeeListComponent 
{
}
